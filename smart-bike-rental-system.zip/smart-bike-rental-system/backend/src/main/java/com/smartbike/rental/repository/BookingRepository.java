package com.smartbike.rental.repository;

import com.smartbike.rental.model.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface BookingRepository extends JpaRepository<Booking, UUID> {
    List<Booking> findByUserIdAndActive(UUID userId, boolean active);
    Optional<Booking> findByBikeIdAndActive(UUID bikeId, boolean active);
}
